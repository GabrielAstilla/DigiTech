<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package goldly
 */
?>
<div class="widget_section">
		<?php dynamic_sidebar('section'); ?>
</div>