=== Ecommerce Goldly ===

Contributors: goldlythemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 4.9
Tested up to: 5.8
Requires PHP: 5.6
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Ecommerce Goldly is a bright blog theme with an absolutely stunning design. The theme is beautifully designed that you can showcase your content effortlessly in a visually appealing way. It supports high-resolution photography and renders the image beautifully on the screen. Also, the design is fully flexible and responsive. The visitors can access the content from any screen size and device without compromising its design display. Easy and powerful customization is one of the best features of Ecommerce Goldly. All of the modifications and edits can be accessed using the WordPress theme customizer.

== License ==

Goldly WordPress Theme, Copyright 2021 Goldly Themes
Goldly is distributed under the terms of the GNU General Public License v2

Ecommerce Goldly WordPress Theme is child theme of Goldly WordPress Theme, Copyright 2021 Goldly Themes
Ecommerce Goldly WordPress Theme is distributed under the terms of the GNU GPL

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Screenshots images ==
1. https://stocksnap.io/photo/laptop-closeup-LX0REZ9RE5
2. https://stocksnap.io/photo/bose-speakers-XJ0O8ERVKJ
3. https://stocksnap.io/photo/still-items-99KAK5LAA7
